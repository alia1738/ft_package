from setuptools import setup

setup(
    name='ft_package',
    version= '0.0.1',
    summary= 'A sample test package',
    home_page= 'https://github.com/alia1738/ft_package',
    author= 'aalsuwai',
    author_email= 'aalsuwai@student.42abudhabi.ae',
    license= 'MIT',
    location= '/home/eagle/...',
    requires= '',
    required_by= '',
    metadata_version= '2.1',
    installer= 'pip',
    classifiers= '',
    entry_points= ''
)
